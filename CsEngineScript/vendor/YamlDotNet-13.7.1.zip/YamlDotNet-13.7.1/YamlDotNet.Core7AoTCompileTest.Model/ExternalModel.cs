﻿namespace YamlDotNet.Core7AoTCompileTest.Model;

public class ExternalModel
{
    public string? Text { get; set; }
}
