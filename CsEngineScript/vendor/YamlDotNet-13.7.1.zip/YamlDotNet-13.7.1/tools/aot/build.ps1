
docker build . -t "aaubry/mono-aot"
