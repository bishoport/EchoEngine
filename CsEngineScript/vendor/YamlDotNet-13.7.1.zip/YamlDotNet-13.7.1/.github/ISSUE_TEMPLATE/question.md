---
name: Question
about: For general usage questions
title: ''
labels: ''
assignees: ''

---

Feel free to ask any question on how to use the library. Alternatively, consider asking the question on [Stackoverflow](https://stackoverflow.com), tagged with [yamldotnet](https://stackoverflow.com/questions/tagged/yamldotnet).
